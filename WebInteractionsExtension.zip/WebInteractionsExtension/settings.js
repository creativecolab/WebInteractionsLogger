const SERVER_URL = "https://creativesearch.ucsd.edu"
const SERVER_DOMAIN = SERVER_URL.substring(8) //Sames as SERVER_URL without https:// in beginning
export{
    SERVER_DOMAIN,
    SERVER_URL
}